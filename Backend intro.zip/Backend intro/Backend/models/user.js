const mongooseUniqueValidator = require('mongoose-unique-validator');

const mongoose = require('mongoose');

const userSchema = mongoose.Schema({
    email: { type: String, required: true, unique: true },
    password: { type: String, required: true }
});

// INSTALL MONGOOSE UNIQUE VALIDATOR TO VALIDATE UNIQUENESS OF EMAIL
//To use mongoose unique validator WE have to improt it
userSchema.plugin(mongooseUniqueValidator);

module.exports = mongoose.model('User', userSchema);