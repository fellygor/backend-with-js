// Using mongoose to create a data model to facilitate database operations
const mongoose = require('mongoose');

// Creating a schema that contains all the fields of our thing
// Their type and whether or not they are required
const thingSchema = mongoose.Schema({
    title: { type: String, required: true },
    description: { type: String, required: true },
    imageUrl: { type: String, required: true },
    userId: { type: String, required: true },
    price: { type: Number, required: true },

});

// Export that schema as a Mongoose model, making it available for your Express app.
module.exports = mongoose.model('Thing', thingSchema);