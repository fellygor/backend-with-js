// WE USE CONTROLLERS TO MAKE OUR CODE MORE MAINTAINABLE
const Thing = require('../models/thing');
// importing our file system
const fs = require('fs');

exports.createThing = (req, res, next) => {
    // We use JSON.parse()
    req.body.thing = JSON.parse(req.body.thing);
    /*
        You need to resolve the full URL because your image req.file.filename  only contains the filename segment. 
        Use  req.protocol  to get the first segment ( 'http' , in this case). Add the  '://' , 
        and then use  req.get('host')  to resolve the server host ('localhost:3000' ). Finally, add  '/images/'  
        and the filename to complete your URL.
    */
    const url = req.protocol + '://' + req.get('host');
    
    // creating a new thing model and passing in json object
    const thing = new Thing({
        title: req.body.thing.title,
        description: req.body.thing.description,
        imageUrl: url + '/images/' + req.file.filename,
        price: req.body.thing.price,
        userId: req.body.thing.userId,

    });
    // save() method is used to save our data in the database
    // We use a promise that includes a then block that sends our feedback to the client 
    // to prevent our request from timimg out
    thing.save().then(
        () => {
            res.status(201).json({
                message: 'Post saved successfully!'
            });
        }
    ).catch(
        (error) => {
            res.status(400).json({
                error: error
            });
        }
    );
};


exports.getOneThing = (req, res, next) => {
    // findOne()  — gets one Thing, based on the comparison function you pass it (often using a Thing's unique identifier.
    Thing.findOne({
        _id: req.params.id
    }).then(
        (thing) => {
            res.status(200).json(thing);
        }
    ).catch(
        (error) => {
            res.status(404).json({
                error:error
            });
        }
    );
};


exports.modifyThing = (req, res, next) => {
    // Create a variable that will pick the thing we want to update
        // const nthing = new Thing({
        //     _id: req.params.id,
        //     title: req.body.title,
        //     description: req.body.description,
        //     imageUrl: req.body.imageUrl,
        //     price: req.body.price,
        //     userId: req.body.userId
        // });\
        // Declare thing and pass in the id of the thing
        let nthing = new Thing({_id: req.params._id});
        // If user is updating the thing with a new file image then
        if(req.file){
            // defining the url of our image
            // req.protocol would be http or https then we are adding the colon and backslash
            // we are getting the localhost port i.e 3000
            const url = req.protocol + '://' + req.get('host');
            // Converts the body of a thing thats coming as a string to JSON object
            req.body.thing = JSON.parse(req.body.thing);
            thing = {
                _id: req.params.id,
                title: req.body.thing.title,
                description: req.body.thing.description,
                // Passing our url here plus the file name req.file.filename
                imageUrl: url + '/images/' + req.file.filename,
                price: req.body.thing.price,
                userId: req.body.thing.userId          
            };
        } 
        // else just do a normal update
        else{
            thing = {
                _id: req.params.id,
                title: req.body.title,
                description: req.body.description,
                imageUrl: req.body.imageUrl,
                price: req.body.price,
                userId: req.body.userId
            };
        }
        Thing.updateOne({_id: req.params.id}, nthing).then(
          () => {
            res.status(201).json({
                message: 'Thing updated successfully!'
            });
          }
        ).catch(
          (error) => {
            res.status(400).json({
              error: error
            });
          }
        );
      };


// Adding functionality to delete things fro our database
exports.deleteThing = (req, res, next) => {
    Thing.findOne({_id: req.params.id}).then(
        (thing) => {
            // creating a constant to capture our image name whoch will be in position 1
            const filename = thing.imageUrl.split('/images/')[1];
            // Then use the  fs  package's  unlink  function to delete that file, 
            // passing it the file to be deleted and the 
            // callback to be executed once that file has been deleted.
            fs.unlink('images/' + filename, () =>{
                // Our call back function that will be used to delete the thing in the database
                Thing.deleteOne({_id: req.params.id}).then(
                    () => {
                        res.status(200).json({
                            message: 'Deleted'
                        });
                    }
                ).catch(
                    (error) => {
                        res.status(400).json({
                            error: error
                        });
                    }
                );  
        });
        }
    )};
   


exports.getAllStuff = (req, res, next) => {
    // find() method on your Mongoose model to return an array containing all of the Thing
    Thing.find().then(
      (things) => {
        res.status(200).json(things);
      }
    ).catch(
      (error) => {
        res.status(400).json({
          error: error
        });
      }
    );
  };
