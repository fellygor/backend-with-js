// WE USE CONTROLLERS TO MAKE OUR CODE MORE MAINTAINABLE
const User = require('../models/user');

// importing json web token JWT
// I helps ensure that every request we receive from the frontend is valid
const jwt = require('jsonwebtoken');

exports.signup = (req, res, next) => {
    // creating a new thing model and passing in json object
    // calling the hash function to encrypt our password plus the number of times we want to encrypt
    // the higher the number : more secure but takes time
    bcryptjs.hash(req.body.password, 10).then(
        (hash) => {
            const user = new User({
                email: req.body.email,
                password: hash
            });
            user.save().then(
                () => {
                    res.status(201).json({
                        message: 'User created successfully!'
                    });
                }
            ).catch(
                (error) => {
                    res.status(500).json({
                        error: error
                    });
                });
        }
    );
   
};

exports.login = (req,res, next) => {
    // check if a user exists with the same email address
    User.findOne({ email: req.body.email }).then(
        (user) => {
          if (!user) {
            return res.status(401).json({
              error: new Error('User not found!')
            });
          }
        //   if email is successful check if the password matches what is stored in the db
          bcryptjs.compare(req.body.password, user.password).then(
            (valid) => {
              if (!valid) {
                return res.status(401).json({
                  error: new Error('Incorrect password!')
                });
              }
            // If your user has valid credentials, return a  200  response containing the user ID 
            // and a token, which we use jsonwebtoken to generate it and encrypt

          // Use jsonwebtoken's  sign  function to encode a new token.
          // That token contains the user's ID as a payload.
          // Use a temporary development secret string to encode your token (to be replaced with a much longer, random string for production).
          // Set the token's validity time to 24 hours.
        // The sign function takes in: sign(Payload, secret key for hashing, configuration object)
            const token = jwt.sign(
              { userId: user._id }, 'RANDOM_TOKEN_SECRET', { expiresIn: '24h'}
            );

            // Send the token back to the front end with your response.
              res.status(200).json({
                userId: user._id,
                token: token,
              });
            }
          ).catch(
            (error) => {
              res.status(500).json({
                error: error
              });
            }
          );
        }
      ).catch(
        (error) => {
          res.status(500).json({
            error: error
          });
        }
      );
}