const express = require('express');
// importing path to help us generate our path
const path = require('path')

const mongoose = require('mongoose');
const app = express();

// imporing schema to use the new Mongoose model in your app,
const Thing = require('./models/thing');
const User = require('./models/user');

const { error } = require('console');
const bodyParser = require('body-parser');

// importing the routes
const stuffRoutes = require('./Routes/stuff')
const userRoutes = require('./Routes/user')

// Connecting to MongoDB
mongoose.connect('mongodb+srv://fellygor:34HshhCWAo4OtMCp@cluster0.sk2r6.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0')
.then(() => {
    console.log('Successfully connected to MongoDB Atlas!');
})
.catch((error) => {
    console.log('Unable to connect to MongoDB Atlas');
    console.error(error);
});

// Adding headers to response objectto allow localhost:3000 and localhost 4200 to communicate
// THis handles cross-origin resource sharing (CORS) errors
app.use((req, res, next) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Headers', 'Origin, X-Requested-With,Accept, Content, Content-Type, Authorization');
    res.setHeader('Access-Control-Allow-Methods', 'GET, PUT, POST, PATCH,OPTIONS, DELETE');
    next();
});

// Making data in the request body easily available
app.use(bodyParser.json());

// Register our routes
app.use('/api/stuff', stuffRoutes);
app.use('/api/auth', userRoutes);

//Telling our app how to handle requests coming from /images
// serve up our static image directory
app.use('/images', express.static(path.join(__dirname, 'images')));
module.exports = app;


// // Create, Read, Update, Delete (CRUD) Operations
// // Middlewares
// // Creating the ability to post messages ie saving data to our database
// app.post('/api/stuff', (req, res) => {
//     // creating a new thing model and passing in json object
//     const thing = new Thing({
//         title: req.body.title,
//         description: req.body.description,
//         imageUrl: req.body.imageUrl,
//         price: req.body.price,
//         userId: req.body.userId,

//     });
//     // save() method is used to save our data in the database
//     // We use a promise that includes a then block that sends our feedback to the client 
//     // to prevent our request from timimg out
//     thing.save().then(
//         () => {
//             res.status(201).json({
//                 message: 'Post saved successfully!'
//             });
//         }
//     ).catch(
//         (error) => {
//             res.status(400).json({
//                 error: error
//             });
//         }
//     );
// });

// //   UPDATE
// // To update a specific item
// app.put('/api/stuff/:id', (req, res, next) => {
//     // Create a variable that will pick the thing we want to update
//         const nthing = new Thing({
//             _id: req.params.id,
//             title: req.body.title,
//             description: req.body.description,
//             imageUrl: req.body.imageUrl,
//             price: req.body.price,
//             userId: req.body.userId
//         });
//         Thing.updateOne({_id: req.params.id}, nthing).then(
//           () => {
//             res.status(201).json({
//                 message: 'Thing updated successfully!'
//             });
//           }
//         ).catch(
//           (error) => {
//             res.status(400).json({
//               error: error
//             });
//           }
//         );
//       });
    
//     //   DELETE
//     // DELETE thing in the list
// app.delete('/api/stuff/:id', (req, res, next) => {
//     Thing.deleteOne({_id: req.params.id}).then(
//         () => {
//             res.status(200).json({
//                 message: 'Deleted'
//             });
//         }
//     ).catch(
//         (error) => {
//             res.status(400).json({
//                 error: error
//             });
//         }
//     );
// });
    

// // Retrieving a specific thing from your schema
// // Use a colon in front of the dynamic segment of the route to make it accessible as a parameter
// app.get('/api/stuff/:id', (req, res) => {
//     // findOne()  — gets one Thing, based on the comparison function you pass it (often using a Thing's unique identifier.
//     Thing.findOne({
//         _id: req.params.id
//     }).then(
//         (thing) => {
//             res.status(200).json(thing);
//         }
//     ).catch(
//         (error) => {
//             res.status(404).json({
//                 error:error
//             });
//         }
//     );
// });

// // Displaying data to the frontend
// app.use('/api/stuff', (req, res, next) => {
//     // find() method on your Mongoose model to return an array containing all of the Thing
//     Thing.find().then(
//       (things) => {
//         res.status(200).json(things);
//       }
//     ).catch(
//       (error) => {
//         res.status(400).json({
//           error: error
//         });
//       }
//     );
//   });


// module.exports = app;


// // app.use((req, res, next) => {
//     res.json({ message: 'This is my server response'});
//     next();
// });

// app.use((req, res, next) => {
//     res.status(400);
//     next();
// });
// app.use((req, res, next) => {
//     console.log('Java is cool!');
// });



// Here we are passing extra arguments /api/stuff which will be our endpoint string
// The output will be http://localhost:3000/api/stuff
// We are also creating an array of stuff which we'll send as JSON data with a 200 status
// app.use('/api/stuff', (req, res, next) => {
//     const stuff = [
//         {
//             _id: 'oeihfzeoi',
//             title: 'My first thing',
//             description: 'All the info about my first thing',
//             imageUrl: '',
//             price: 4900,
//             userId: 'qwerty',
//         },
//         {
//             _id: 'ghregdgh',
//             title: 'My first thing',
//             description: 'All the info about my second thing',
//             imageUrl: '',
//             price: 2345,
//             userId: 'sdfgh',
//         },
//         {
//             _id: 'ytuttututu',
//             title: 'My third thing',
//             description: 'All the info about my third thing',
//             imageUrl: '',
//             price: 9800,
//             userId: 'xcvbn',
//         },
//     ];
//     res.status(200).json(stuff);
// });