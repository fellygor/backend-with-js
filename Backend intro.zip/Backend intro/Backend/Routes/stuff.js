const express = require('express');
const router = express.Router();

// Adding our auth.js middleware to stuff routes : thw routes we want to protect
const auth = require('../middleware/auth');
const multer = require('../middleware/multer-config');

// Importing our controllers into the routes
const stuffController = require('../controllers/stuff');



// DEFINING OUR ROUTES
router.post('/', auth,  multer, stuffController.createThing);
router.get('/:id', auth, stuffController.getOneThing);
router.put('/:id', auth, multer, stuffController.modifyThing);
router.delete('/:id',auth, stuffController.deleteThing);
router.get('/', auth, stuffController.getAllStuff);

module.exports = router;