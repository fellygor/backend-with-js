const express = require('express');
// Importing our controllers into the routes
const userController = require('../controllers/user');

const router = express.Router();

// DEFINING OUR ROUTES
router.post('/signup', userController.signup);
router.post('/login', userController.login);

module.exports = router;