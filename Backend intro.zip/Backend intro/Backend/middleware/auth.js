// We want to protect selected routes and ensure that a user is authenticated before 
// allowing their requests to go through. Let's start!


const jwt = require('jsonwebtoken');
const user = require('../models/user');

module.exports = (res, req, next) => {
    // Because of many anticpitated errors we use try ... catch block
    try{
        // WE want to decode our jwt token and 
        // splitting our token using spaces
        const token = req.headers.authorization.split(' ')[1];

        // Using verify() function to decode our token
        const decodedToken = jwt.verify(token, 'RANDOM_TOKEN_SECRET');

        // Extract user Id from your token
        const userId = decodedToken.userId;

        // check if the decoded user id matches one that has sent a request
        if(req.body.userId && req.body.userId !== userId) {
            throw 'Invalid user ID';
        }
        // If matches pass the execution to the following middleware using next()
        else{
            next();
        }
    }
    catch{
        res.status(401).json({
            error: new Error('Invalid request!')
        })
    }
}